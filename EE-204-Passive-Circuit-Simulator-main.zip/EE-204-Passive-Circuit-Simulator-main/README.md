# EE 204 Course Project
We'll summarise the entire project in the README.

### GUI

<img width="1211" alt="Screenshot 2024-11-27 at 12 59 07 PM" src="https://github.com/user-attachments/assets/2d16be0e-4dea-43ea-bc8c-fc1cd63c036f">
